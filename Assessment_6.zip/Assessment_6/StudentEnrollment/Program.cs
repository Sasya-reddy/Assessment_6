﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentEnrollment
{
    public class Student
    {
        public int StudentID { get; set; }
        public string Name { get; set; }
    }

    public class Enrollment
    {
        public int StudentID { get; set; }
        public string Course { get; set; }
    }

    internal class Program
    {
    }
}
