﻿using StudentEnrollment;
using System;
using System.Collections.Generic;
using System.Linq;


namespace StudentEnrollment
{
    class EnrollmentDetails
    {
        static void Main()
        {
            
            var students = new List<Student>
            {
                new Student { StudentID = 1, Name = "Sasya" },
                new Student { StudentID = 2, Name = "Sahi" },
                new Student { StudentID = 3, Name = "Manas" }
            };

            
            var enrollments = new List<Enrollment>
            {
                new Enrollment { StudentID = 557, Course = "Java" },
                new Enrollment { StudentID = 521, Course = "Js" },
                new Enrollment { StudentID = 511, Course = "C#" },
                
            };

            // LINQ query 
            var studentCourses = from student in students
                                 join enrollment in enrollments
                                 on student.StudentID equals enrollment.StudentID
                                 group new { student.Name, enrollment.Course } by student.Name into studentGroup
                                 select new
                                 {
                                     StudentName = studentGroup.Key,
                                     Courses = studentGroup.Select(x => x.Course).ToList()
                                 };

            // Display the results
            foreach (var student in studentCourses)
            {
                Console.WriteLine($"Student: {student.StudentName}");
                Console.WriteLine("Courses:");
                foreach (var course in student.Courses)
                {
                    Console.WriteLine($"- {course}");
                }
                Console.WriteLine();
            }
            
        }
    }
   
}
