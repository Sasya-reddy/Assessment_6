﻿using System;

class Pattern
{
    static void Main()
    {
        int rows = 5; // Number of rows for the pattern

        for (int i = 1; i <= rows; i++)
        {
            for (int j = 1; j <= i; j++)
            {
                Console.Write(j + " ");
            }
            Console.WriteLine(); // Move to the next line after printing each row
        }
    }
}
