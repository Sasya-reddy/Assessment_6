﻿namespace Assesment_6
{
    internal class NumberGuess
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcom to Guess the Number Game..");
            Console.WriteLine("Please Enter Your Guess Number (From Range of 1-100): ");
            int inputNum = Convert.ToInt32(Console.ReadLine());
            Random num = new Random();
            int randomNum = num.Next(0, 101);

            if (inputNum != 0)
            {
                if (inputNum == randomNum)
                {
                    Console.WriteLine("Hurrayy...Your Guess is Right ;)");
                }
                else
                {
                    Console.WriteLine("oops Not Matched");
                    Console.WriteLine("The Random Number Generated is: " + randomNum);
                }
            }
        }
    }
}