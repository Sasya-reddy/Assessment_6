﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnAssessment
{
    class Operations
    {
        static void Main(string[] args)
        {
           
            int[] numbers = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 };         
            int sum = numbers.Sum();
            Console.WriteLine($"Sum of all elements: {sum}");        
            double average = numbers.Average();
            Console.WriteLine($"Average of all elements: {average}");          
            int max = numbers.Max();
            Console.WriteLine($"Maximum value: {max}");
            int min = numbers.Min();
            Console.WriteLine($"Minimum value: {min}");
        }

    }
   
}

