﻿using System;

class PrimeNumbers
{
    static void Main()
    {
        Console.Write("Enter the number of prime numbers you want: ");
        int n = int.Parse(Console.ReadLine());
        int count = 0;
        int number = 2;

        while (count < n)
        {
            if (IsPrime(number))
            {
                Console.WriteLine(number);
                count++;
            }
            number++;
        }
    }

    static bool IsPrime(int num)
    {
        for (int i = 2; i < num; i++)
        {
            if (num % i == 0)
                return false;
        }
        return true;
    }
}
