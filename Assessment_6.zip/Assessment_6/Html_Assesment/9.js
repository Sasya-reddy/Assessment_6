class Book {
    // Constructor to initialize the properties
    constructor(title, author, publicationYear) {
        this.title = title;
        this.author = author;
        this.publicationYear = publicationYear;
    }

    // Method to display the book details
    displayDetails() {
        console.log(`Title: ${this.title}`);
        console.log(`Author: ${this.author}`);
        console.log(`Publication Year: ${this.publicationYear}`);
    }
}


const myBook = new Book("Good Things", "Harper Lee", 1960);
myBook.displayDetails();


