function squareNumbers(numbers) {
    return numbers.map(num => num * num);
}

const numbers = [1, 2, 3, 4, 5];
const squaredNumbers = squareNumbers(numbers);

console.log(squaredNumbers);